<html>

<head>

<style>

body{
font-family:Arial;
background:#f4f7fb;
}

.box{
width:450px;
margin:100px auto;
background:white;
padding:30px;
text-align:center;
border-radius:15px;
box-shadow:0px 0px 15px lightgray;
}

a{
text-decoration:none;
}

</style>

</head>

<body>

<div class="box">

<h2>Book Saved Successfully</h2>

<a href="index.jsp">

Add More Books

</a>

</div>

</body>

</html>