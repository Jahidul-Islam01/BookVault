<%@ page import="java.sql.*" %>

<%
Class.forName("com.mysql.cj.jdbc.Driver");
Connection con = DriverManager.getConnection(
    "jdbc:mysql://localhost:3306/libraryhub","root",""
);

Statement st = con.createStatement();
ResultSet rs = st.executeQuery("SELECT * FROM books WHERE deleted=1");
%>

<html>
<head>
<title>Recycle Bin</title>
<style>
body{ font-family:Arial; background:#eef2f7; }
h1{text-align:center;}
table{width:90%; margin:auto; background:white; border-collapse:collapse;}
th{background:#e74c3c; color:white; padding:10px;}
td{padding:10px; border:1px solid #ddd; text-align:center;}
</style>
</head>

<body>
<h1>Recycle Bin</h1>

<table>
<tr>
<th>Book ID</th> <!-- display book_id -->
<th>Book Title</th>
<th>Author</th>
<th>Action</th>
</tr>

<%
while(rs.next()){
%>
<tr>
<td><%=rs.getString("book_id")%></td> <!-- use book_id instead of auto_increment id -->
<td><%=rs.getString("title")%></td>
<td><%=rs.getString("author")%></td>
<td>
<a href="restore.jsp?id=<%=rs.getInt("id")%>">Restore</a>
</td>
</tr>
<%
}
rs.close();
st.close();
con.close();
%>

</table>
</body>
</html>