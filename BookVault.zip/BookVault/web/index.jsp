<html>

<head>

<title>BookVault Management System</title>

<style>

body{
font-family:Arial;
background:#f4f7fb;
}

.container{
width:600px;
margin:40px auto;
background:white;
padding:30px;
border-radius:15px;
box-shadow:0px 0px 15px lightgray;
}

h1{
text-align:center;
color:#1f3c88;
}

p{
text-align:center;
color:gray;
}

input,select{
width:100%;
padding:10px;
margin-top:5px;
margin-bottom:15px;
border:1px solid #ccc;
border-radius:5px;
}

button{
width:100%;
padding:12px;
background:#1f3c88;
color:white;
border:none;
border-radius:5px;
cursor:pointer;
}

button:hover{
background:#142a63;
}

.link{
text-align:center;
margin-top:20px;
}

</style>

</head>

<body>

<div class="container">

<h1>BookVault Management System</h1>

<p>Manage library books efficiently</p>

<form action="save.jsp" method="post">

Book ID

<input type="text" name="bookid" required>

Book Title

<input type="text" name="title" required>

Author Name

<input type="text" name="author" required>

Genre

<select name="genre">

<option>Programming</option>
<option>Novel</option>
<option>Science</option>
<option>History</option>

</select>

Status

<select name="status">

<option>Available</option>
<option>Issued</option>
<option>Reserved</option>
<option>Lost</option>

</select>

<button type="submit">

Save Book

</button>

</form>

<div class="link">

<a href="view.jsp">

View Books

</a>

</div>

</div>

</body>

</html>