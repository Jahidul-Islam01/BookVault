<%@ page import="java.sql.*" %>

<%

int id=Integer.parseInt(
request.getParameter("id")
);

Class.forName("com.mysql.cj.jdbc.Driver");

Connection con=DriverManager.getConnection(
"jdbc:mysql://localhost:3306/libraryhub",
"root",
""
);

PreparedStatement ps=
con.prepareStatement(
"UPDATE books SET deleted=0 WHERE id=?"
);

ps.setInt(1,id);

ps.executeUpdate();

response.sendRedirect("recyclebin.jsp");

%>