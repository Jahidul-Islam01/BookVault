<%@ page import="java.sql.*" %>

<%

String bookid=request.getParameter("bookid");

String title=request.getParameter("title");

String author=request.getParameter("author");

String genre=request.getParameter("genre");

String status=request.getParameter("status");

Class.forName("com.mysql.cj.jdbc.Driver");

Connection con=DriverManager.getConnection(
"jdbc:mysql://localhost:3306/libraryhub",
"root",
""
);

PreparedStatement ps=con.prepareStatement(
"insert into books(book_id,title,author,genre,status) values(?,?,?,?,?)"
);

ps.setString(1,bookid);
ps.setString(2,title);
ps.setString(3,author);
ps.setString(4,genre);
ps.setString(5,status);

ps.executeUpdate();

response.sendRedirect("success.jsp");

%>