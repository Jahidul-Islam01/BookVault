<%@ page import="java.sql.*" %>

<%
Class.forName("com.mysql.cj.jdbc.Driver");

Connection con=DriverManager.getConnection(
"jdbc:mysql://localhost:3306/libraryhub",
"root",
""
);

Statement st=con.createStatement();

ResultSet totalRs=st.executeQuery("SELECT COUNT(*) FROM books WHERE deleted=0");
totalRs.next();
int total=totalRs.getInt(1);

ResultSet availableRs=st.executeQuery("SELECT COUNT(*) FROM books WHERE status='Available' AND deleted=0");
availableRs.next();
int available=availableRs.getInt(1);

ResultSet issuedRs=st.executeQuery("SELECT COUNT(*) FROM books WHERE status='Issued' AND deleted=0");
issuedRs.next();
int issued=issuedRs.getInt(1);

ResultSet reservedRs=st.executeQuery("SELECT COUNT(*) FROM books WHERE status='Reserved' AND deleted=0");
reservedRs.next();
int reserved=reservedRs.getInt(1);

ResultSet lostRs=st.executeQuery("SELECT COUNT(*) FROM books WHERE status='Lost' AND deleted=0");
lostRs.next();
int lost=lostRs.getInt(1);

ResultSet rs=st.executeQuery("SELECT * FROM books WHERE deleted=0");
%>

<html>
<head>
<title>BookVault Dashboard</title>
<style>
body{font-family:Arial;background:#eef2f7;}
h1{text-align:center;}
.cards{display:flex;justify-content:center;gap:15px;flex-wrap:wrap;margin-bottom:25px;}
.card{width:150px;padding:15px;text-align:center;color:white;border-radius:10px;}
.total{background:#2c3e50;}
.available{background:#27ae60;}
.issued{background:#3498db;}
.reserved{background:#f39c12;}
.lost{background:#e74c3c;}
table{width:95%;margin:auto;border-collapse:collapse;background:white;}
th{background:#1f3c88;color:white;padding:10px;}
td{padding:10px;border:1px solid #ddd;text-align:center;}
</style>
</head>
<body>

<h1>BookVault Dashboard</h1>
<div style="text-align:center;margin-bottom:20px;">
<a href="recyclebin.jsp" style="background:#e74c3c;color:white;padding:10px 15px;border-radius:5px;text-decoration:none;">Open Recycle Bin</a>
</div>

<div style="width:600px;margin:20px auto;background:white;padding:25px;border-radius:15px;box-shadow:0 0 15px lightgray;">
<h2 style="text-align:center;color:#1f3c88;">Library Summary</h2>
<hr>
<p>Total Books : <b><%=total%></b></p>
<p>Available Books : <b><%=available%></b></p>
<p>Issued Books : <b><%=issued%></b></p>
<p>Reserved Books : <b><%=reserved%></b></p>
<p>Lost Books : <b><%=lost%></b></p>
</div>

<table>
<tr>
<th>Serial</th>
<th>Book ID</th>
<th>Title</th>
<th>Author</th>
<th>Genre</th>
<th>Status</th>
<th>Action</th>
</tr>

<%
int serial = 1; // Initialize serial number
while(rs.next()){
%>
<tr>
<td><%=serial++%></td> <!-- Serial number increment -->
<td><%=rs.getString("book_id")%></td>
<td><%=rs.getString("title")%></td>
<td><%=rs.getString("author")%></td>
<td><%=rs.getString("genre")%></td>
<td><%=rs.getString("status")%></td>
<td><a href="delete.jsp?id=<%=rs.getInt("id")%>">Delete</a></td>
</tr>
<%
}
%>
</table>

</body>
</html>